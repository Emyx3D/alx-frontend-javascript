# Installation
> `npm install --save @types/babel__template`

# Summary
This package contains type definitions for @babel/template (https://github.com/babel/babel/tree/master/packages/babel-template).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babel__template.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 18:05:41 GMT
 * Dependencies: [@types/babel__parser](https://npmjs.com/package/@types/babel__parser), [@types/babel__types](https://npmjs.com/package/@types/babel__types)
 * Global values: none

# Credits
These definitions were written by [Troy Gerwien](https://github.com/yortus), [Marvin Hagemeister](https://github.com/marvinhagemeister), [Melvin Groenhoff](https://github.com/mgroenhoff), and [ExE Boss](https://github.com/ExE-Boss).
